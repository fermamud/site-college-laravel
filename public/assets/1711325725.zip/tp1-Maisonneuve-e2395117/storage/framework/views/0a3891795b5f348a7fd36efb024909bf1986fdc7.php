<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
    <header class="">
        <img src="<?php echo e(asset('images/logo.svg')); ?>" class="logo" alt="Logo">
        <nav class="nav nav-pills flex-column flex-sm-row m-5">
            <?php if(request()->routeIs('etudiant.show')): ?>
            <a class="flex-sm-fill text-sm-center nav-link <?php echo e(request()->routeIs('etudiant.show') ? 'active' : ''); ?>" href="<?php echo e(route('etudiant.index')); ?>">Détails de l'étudiant</a>
            <?php elseif(request()->routeIs('etudiant.edit')): ?>
            <a class="flex-sm-fill text-sm-center nav-link <?php echo e(request()->routeIs('etudiant.edit') ? 'active' : ''); ?>" href="<?php echo e(route('etudiant.index')); ?>">Modification d'un étudiant</a>  
            <?php else: ?>
            <a class="flex-sm-fill text-sm-center nav-link" href="/">Accueil</a>
            <?php endif; ?>
            <a class="flex-sm-fill text-sm-center nav-link <?php echo e(request()->routeIs('etudiant.index') ? 'active' : ''); ?>" href="<?php echo e(route('etudiant.index')); ?>">Liste des étudiants</a>
            <a class="flex-sm-fill text-sm-center nav-link <?php echo e(request()->routeIs('etudiant.create') ? 'active' : ''); ?>" href="<?php echo e(route('etudiant.create')); ?>">Ajouter un étudiant</a>
        </nav>
    </header>
    <main>
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissable fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-lable="Close"></button>
            </div>
        <?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <footer class="footer py-2 bg-dark text-white">
        <div class="container text-center">
            &copy;Collège de Maisonneuve. All rights reserved
        </div>
    </footer>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</html><?php /**PATH C:\582-41B-MA_CADRICIEL_WEB\tp1-Maisonneuve-e2395117\resources\views/layouts/app.blade.php ENDPATH**/ ?>