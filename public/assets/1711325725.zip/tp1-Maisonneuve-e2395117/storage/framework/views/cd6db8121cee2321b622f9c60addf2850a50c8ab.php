
<?php $__env->startSection('title', 'Ajouter un étudiant'); ?>
<?php $__env->startSection('content'); ?>
<h1 class="my-5 text-center">Ajouter un étudiant</h1>
<form class="row g-3 m-5 justify-content-center" method="POST">
    <?php echo csrf_field(); ?>
    <div class="col-5">
      <label for="nom" class="form-label">Nom</label>
      <input type="text" name="nom" class="form-control" id="nom" placeholder="Marie Tremblay" value="<?php echo e(old('nom')); ?>">
      <?php if($errors->has('nom')): ?>
        <div class="text-danger mt-2">
            <?php echo e($errors->first('nom')); ?>

        </div>
      <?php endif; ?>
    </div>
    <div class="col-5">
      <label for="adresse" class="form-label">Address</label>
      <input type="text" name="adresse" class="form-control" id="adresse" placeholder="1117 Avenue Mont Royal" value="<?php echo e(old('adresse')); ?>">
      <?php if($errors->has('adresse')): ?>
        <div class="text-danger mt-2">
            <?php echo e($errors->first('adresse')); ?>

        </div>
      <?php endif; ?>
    </div>
    <div class="col-5">
      <label for="telephone" class="form-label">Telephone</label>
      <input type="tel" name="telephone" class="form-control" id="telephone" placeholder="514-608-1738" value="<?php echo e(old('telephone')); ?>">
      <?php if($errors->has('adresse')): ?>
        <div class="text-danger mt-2">
            <?php echo e($errors->first('telephone')); ?>

        </div>
      <?php endif; ?>
    </div>
  <div class="col-5">
    <label for="email" class="form-label">Email</label>
    <input type="email" name="email" class="form-control" id="email" placeholder="marie@gmail.com">
    <?php if($errors->has('email')): ?>
      <div class="text-danger mt-2">
          <?php echo e($errors->first('email')); ?>

      </div>
    <?php endif; ?>
  </div>
  <div class="col-5">
    <label for="date_naissance" class="form-label">Date Naissance</label>
    <input type="date" name="date_naissance" class="form-control" id="date_naissance" value="<?php echo e(old('date_naissance')); ?>">
    <?php if($errors->has('date_naissance')): ?>
      <div class="text-danger mt-2">
          <?php echo e($errors->first('date_naissance')); ?>

      </div>
    <?php endif; ?>
  </div>
  <div class="col-5">
    <label for="ville_nom" class="form-label">Ville Nom</label>
    <select name="ville_id" id="ville_nom" class="form-control">
        <option value="0">Sélectionnez une ville</option>
        <?php $__currentLoopData = $villes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ville): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($ville->id); ?>" <?php echo e(old('ville_id') == $ville->id ? 'selected' : ''); ?>><?php echo e($ville->nom); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php if($errors->has('ville_id')): ?>
      <div class="text-danger mt-2">
        <?php echo e($errors->first('ville_id')); ?>

      </div>
    <?php endif; ?>
  </div>
  <div class="col-10">
    <button type="submit" class="btn btn-primary">Ajouter</button>
  </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\582-41B-MA_CADRICIEL_WEB\tp1-Maisonneuve-e2395117\resources\views/etudiant/create.blade.php ENDPATH**/ ?>