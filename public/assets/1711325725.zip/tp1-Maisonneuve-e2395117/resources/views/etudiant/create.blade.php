@extends('layouts.app')
@section('title', 'Ajouter un étudiant')
@section('content')
<h1 class="my-5 text-center">Ajouter un étudiant</h1>
<form class="row g-3 m-5 justify-content-center" method="POST">
    @csrf
    <div class="col-5">
      <label for="nom" class="form-label">Nom</label>
      <input type="text" name="nom" class="form-control" id="nom" placeholder="Marie Tremblay" value="{{ old('nom') }}">
      @if($errors->has('nom'))
        <div class="text-danger mt-2">
            {{ $errors->first('nom') }}
        </div>
      @endif
    </div>
    <div class="col-5">
      <label for="adresse" class="form-label">Address</label>
      <input type="text" name="adresse" class="form-control" id="adresse" placeholder="1117 Avenue Mont Royal" value="{{ old('adresse') }}">
      @if($errors->has('adresse'))
        <div class="text-danger mt-2">
            {{ $errors->first('adresse') }}
        </div>
      @endif
    </div>
    <div class="col-5">
      <label for="telephone" class="form-label">Telephone</label>
      <input type="tel" name="telephone" class="form-control" id="telephone" placeholder="514-608-1738" value="{{ old('telephone') }}">
      @if($errors->has('adresse'))
        <div class="text-danger mt-2">
            {{ $errors->first('telephone') }}
        </div>
      @endif
    </div>
  <div class="col-5">
    <label for="email" class="form-label">Email</label>
    <input type="email" name="email" class="form-control" id="email" placeholder="marie@gmail.com">
    @if($errors->has('email'))
      <div class="text-danger mt-2">
          {{ $errors->first('email') }}
      </div>
    @endif
  </div>
  <div class="col-5">
    <label for="date_naissance" class="form-label">Date Naissance</label>
    <input type="date" name="date_naissance" class="form-control" id="date_naissance" value="{{ old('date_naissance') }}">
    @if($errors->has('date_naissance'))
      <div class="text-danger mt-2">
          {{ $errors->first('date_naissance') }}
      </div>
    @endif
  </div>
  <div class="col-5">
    <label for="ville_nom" class="form-label">Ville Nom</label>
    <select name="ville_id" id="ville_nom" class="form-control">
        <option value="0">Sélectionnez une ville</option>
        @foreach($villes as $ville)
        <option value="{{ $ville->id }}" {{ old('ville_id') == $ville->id ? 'selected' : '' }}>{{ $ville->nom }}</option>
        @endforeach
    </select>
    @if($errors->has('ville_id'))
      <div class="text-danger mt-2">
        {{ $errors->first('ville_id') }}
      </div>
    @endif
  </div>
  <div class="col-10">
    <button type="submit" class="btn btn-primary">Ajouter</button>
  </div>
</form>
@endsection