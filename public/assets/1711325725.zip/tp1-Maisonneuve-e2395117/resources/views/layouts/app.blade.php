<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title')</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
    <header class="">
        <img src="{{ asset('images/logo.svg') }}" class="logo" alt="Logo">
        <nav class="nav nav-pills flex-column flex-sm-row m-5">
            @if(request()->routeIs('etudiant.show'))
            <a class="flex-sm-fill text-sm-center nav-link {{ request()->routeIs('etudiant.show') ? 'active' : '' }}" href="{{ route('etudiant.index') }}">Détails de l'étudiant</a>
            @elseif(request()->routeIs('etudiant.edit'))
            <a class="flex-sm-fill text-sm-center nav-link {{ request()->routeIs('etudiant.edit') ? 'active' : '' }}" href="{{ route('etudiant.index') }}">Modification d'un étudiant</a>  
            @else
            <a class="flex-sm-fill text-sm-center nav-link" href="/">Accueil</a>
            @endif
            <a class="flex-sm-fill text-sm-center nav-link {{ request()->routeIs('etudiant.index') ? 'active' : '' }}" href="{{ route('etudiant.index') }}">Liste des étudiants</a>
            <a class="flex-sm-fill text-sm-center nav-link {{ request()->routeIs('etudiant.create') ? 'active' : '' }}" href="{{ route('etudiant.create') }}">Ajouter un étudiant</a>
        </nav>
    </header>
    <main>
        @if(session('success'))
            <div class="alert alert-success alert-dismissable fade show" role="alert">
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-lable="Close"></button>
            </div>
        @endif
        @yield('content')
    </main>
    <footer class="footer py-2 bg-dark text-white">
        <div class="container text-center">
            &copy;Collège de Maisonneuve. All rights reserved
        </div>
    </footer>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</html>