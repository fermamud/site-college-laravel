
<?php $__env->startSection('title', 'Détails d\'un étudiant'); ?>
<?php $__env->startSection('content'); ?>
<h1 class="my-5 text-center">Détails d'un étudiant</h1>
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="card-title"><?php echo e($etudiant->nom); ?></h5>
                </div>
                <div class="card-body">
                    <p class="card-text"><?php echo e($etudiant->adresse); ?></p>
                    <ul clas="list-unstyled">
                        <li><strong>Email :</strong> <?php echo e($etudiant->email); ?></li>
                        <li><strong>Date Naissance :</strong> <?php echo e($etudiant->date_naissance); ?></li>
                        <li><strong>Ville Id :</strong> <?php echo e($etudiant->ville_id); ?></li>
                        <li><strong>Ville Nom :</strong> <?php echo e($etudiant->ville->nom); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\582-41B-MA_CADRICIEL_WEB\tp1-Maisonneuve-e2395117\resources\views/etudiant/show.blade.php ENDPATH**/ ?>