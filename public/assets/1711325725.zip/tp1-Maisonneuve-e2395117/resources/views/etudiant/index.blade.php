@extends('layouts.app')
@section('title', 'Liste des étudiants')
@section('content')
<h1 class="m-5">Liste des Étudiants</h1>
    <div class="table-responsive{-sm|-md|-lg|-xl} m-5">
        <table class="table caption-top">
            <thead>
                <tr>
                <th scope="col">Nom</th>
                <th scope="col" class="adresse">Adresse</th>
                <th scope="col" class="telephone">Telephone</th>
                <th scope="col">Email</th>
                <th scope="col">Date Naissance</th>
                <!-- <th scope="col">Ville id</th> -->
                <th scope="col">Ville Nom</th>
                <th scope="col">Détails</th>
                <th scope="col">Modification</th>
                <th scope="col">Suppression</th>
                </tr>
            </thead>
            <tbody>
            @forelse($etudiants as $etudiant)
                <tr>
                    <th>{{ $etudiant->nom }}</th>
                    <td class="adresse">{{ $etudiant->adresse }}</td>
                    <td class="telephone">{{ $etudiant->telephone }}</td>
                    <td>{{ $etudiant->email }}</td>
                    <td>{{ $etudiant->date_naissance }}</td>
                    <td>{{ $etudiant->ville->nom }}</td>
                    <td><a href="{{ route('etudiant.show', $etudiant->id) }}" class="btn btn-sm btn-outline-primary">View</a></td>
                    <td><a href="{{ route('etudiant.edit', $etudiant->id) }}" class="btn btn-sm btn-outline-primary">Modification</a></td>
                    <td>
                        <form action="{{ route('etudiant.delete', $etudiant->id) }}" method="post">
                            @csrf
                            @method('delete')
                            <button type="submit" class="btn btn-sm btn-danger">Supprimer</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="9">
                        <div class="alert alert-danger">Il n'y a aucun étudiant dans la liste !</div>
                    </td>
                </tr>
            @endforelse
            </tbody>
        </table>
    </div>
@endsection