
<?php $__env->startSection('title', 'Liste des étudiants'); ?>
<?php $__env->startSection('content'); ?>
<h1 class="m-5">Liste des Étudiants</h1>
    <div class="table-responsive{-sm|-md|-lg|-xl} m-5">
        <table class="table caption-top">
            <thead>
                <tr>
                <th scope="col">Nom</th>
                <th scope="col" class="adresse">Adresse</th>
                <th scope="col" class="telephone">Telephone</th>
                <th scope="col">Email</th>
                <th scope="col">Date Naissance</th>
                <!-- <th scope="col">Ville id</th> -->
                <th scope="col">Ville Nom</th>
                <th scope="col">Détails</th>
                <th scope="col">Modification</th>
                <th scope="col">Suppression</th>
                </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $etudiants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th><?php echo e($etudiant->nom); ?></th>
                    <td class="adresse"><?php echo e($etudiant->adresse); ?></td>
                    <td class="telephone"><?php echo e($etudiant->telephone); ?></td>
                    <td><?php echo e($etudiant->email); ?></td>
                    <td><?php echo e($etudiant->date_naissance); ?></td>
                    <td><?php echo e($etudiant->ville->nom); ?></td>
                    <td><a href="<?php echo e(route('etudiant.show', $etudiant->id)); ?>" class="btn btn-sm btn-outline-primary">View</a></td>
                    <td><a href="<?php echo e(route('etudiant.edit', $etudiant->id)); ?>" class="btn btn-sm btn-outline-primary">Modification</a></td>
                    <td>
                        <form action="<?php echo e(route('etudiant.delete', $etudiant->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button type="submit" class="btn btn-sm btn-danger">Supprimer</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="9">
                        <div class="alert alert-danger">Il n'y a aucun étudiant dans la liste !</div>
                    </td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\582-41B-MA_CADRICIEL_WEB\tp1-Maisonneuve-e2395117\resources\views/etudiant/index.blade.php ENDPATH**/ ?>