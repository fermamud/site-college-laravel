@extends('layouts.app')
@section('title', 'Détails d\'un étudiant')
@section('content')
<h1 class="my-5 text-center">Détails d'un étudiant</h1>
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="card-title">{{ $etudiant->nom }}</h5>
                </div>
                <div class="card-body">
                    <p class="card-text">{{ $etudiant->adresse }}</p>
                    <ul clas="list-unstyled">
                        <li><strong>Email :</strong> {{ $etudiant->email }}</li>
                        <li><strong>Date Naissance :</strong> {{ $etudiant->date_naissance }}</li>
                        <li><strong>Ville Id :</strong> {{ $etudiant->ville_id }}</li>
                        <li><strong>Ville Nom :</strong> {{$etudiant->ville->nom }}</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
@endsection



