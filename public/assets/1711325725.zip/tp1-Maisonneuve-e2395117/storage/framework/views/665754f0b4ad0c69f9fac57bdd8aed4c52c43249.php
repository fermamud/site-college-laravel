
<?php $__env->startSection('content'); ?>
<h1 class="m-5">Liste des Étudiants</h1>
    <div class="table-responsive m-5">
        <table class="table caption-top">
            <thead>
                <tr>
                <th scope="col">Nom</th>
                <th scope="col">Adresse</th>
                <th scope="col">Telephone</th>
                <th scope="col">Email</th>
                <th scope="col">Date Naissance</th>
                <th scope="col">Ville id</th>
                <th scope="col">Détails</th>
                <th scope="col">Suppression</th>
                </tr>
            </thead>
            <?php $__empty_1 = true; $__currentLoopData = $etudiants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tbody>
                <tr>
                    <th><?php echo e($etudiant->nom); ?></th>
                    <td><?php echo e($etudiant->adresse); ?></td>
                    <td><?php echo e($etudiant->telephone); ?></td>
                    <td><?php echo e($etudiant->email); ?></td>
                    <td><?php echo e($etudiant->date_naissance); ?></td>
                    <td><?php echo e($etudiant->ville_id); ?></td>
                    <td><a href="" class="btn btn-sm btn-outline-primary">View</a></td>
                    <td><a href="" class="btn btn-sm btn-outline-primary">Supprimer</a></td>
                </tr>
            </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        </table>
    </div>
        <div class="alert alert-danger">Il n'y a aucun étudiant dans la liste !</div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\582-41B-MA_CADRICIEL_WEB\tp1-Maisonneuve-e2395117\resources\views/etudiants/index.blade.php ENDPATH**/ ?>