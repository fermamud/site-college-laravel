
<?php $__env->startSection('title', 'Modification d\'un étudiant'); ?>
<?php $__env->startSection('content'); ?>
<h1 class="m-5 text-center">Modification d'Étudiant</h1>
<form class="row g-3 m-5 justify-content-center" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>
    <div class="col-5">
      <label for="nom" class="form-label">Nom</label>
      <input type="text" name="nom" class="form-control" id="nom" value="<?php echo e(old('nom', $etudiant->nom)); ?>">
      <?php if($errors->has('nom')): ?>
        <div class="text-danger mt-2">
            <?php echo e($errors->first('nom')); ?>

        </div>
      <?php endif; ?>
    </div>
    <div class="col-5">
      <label for="adresse" class="form-label">Adresse</label>
      <input type="text" name="adresse" class="form-control" id="adresse" value="<?php echo e(old('adresse', $etudiant->adresse)); ?>">
      <?php if($errors->has('adresse')): ?>
        <div class="text-danger mt-2">
            <?php echo e($errors->first('adresse')); ?>

        </div>
      <?php endif; ?>
    </div>
    <div class="col-md-5">
      <label for="telephone" class="form-label">Telephone</label>
      <input type="tel" name="telephone" class="form-control" id="telephone" value="<?php echo e(old('telephone', $etudiant->telephone)); ?>">
      <?php if($errors->has('adresse')): ?>
        <div class="text-danger mt-2">
            <?php echo e($errors->first('telephone')); ?>

        </div>
      <?php endif; ?>
    </div>
  <div class="col-md-5">
    <label for="email" class="form-label">Email</label>
    <input type="email" name="email" class="form-control" id="email" value="<?php echo e(old('email', $etudiant->email)); ?>">
    <?php if($errors->has('email')): ?>
      <div class="text-danger mt-2">
          <?php echo e($errors->first('email')); ?>

      </div>
    <?php endif; ?>
  </div>
  <div class="col-md-5">
    <label for="date_naissance" class="form-label">Date Naissance</label>
    <input type="date" name="date_naissance" class="form-control" id="date_naissance" value="<?php echo e(old('date_naissance', $etudiant->date_naissance)); ?>">
    <?php if($errors->has('date_naissance')): ?>
      <div class="text-danger mt-2">
          <?php echo e($errors->first('date_naissance')); ?>

      </div>
    <?php endif; ?>
  </div>
  <!-- <div class="col-md-4">
    <label for="ville_id" class="form-label">Ville Id</label>
    <input type="number" name="ville_id" class="form-control" id="ville_id" value="<?php echo e($etudiant->ville_id); ?>">
  </div> -->

  <!-- FALTA AQUI INCLUIR O OLD -->

  <div class="col-md-5">
    <label for="ville_nom" class="form-label">Ville Nom</label>
    <select name="ville_id" id="ville_nom" class="form-control">
        <option value="<?php echo e($etudiant->ville_id); ?>"><?php echo e($etudiant->ville->nom); ?></option>
        <?php $__currentLoopData = $villes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ville): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($ville->id); ?>"><?php echo e($ville->nom); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php if($errors->has('ville_id')): ?>
      <div class="text-danger mt-2">
          <?php echo e($errors->first('ville_id')); ?>

      </div>
    <?php endif; ?>
  </div>


  <div class="col-10">
    <button type="submit" class="btn btn-primary">Modifier</button>
  </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\582-41B-MA_CADRICIEL_WEB\tp1-Maisonneuve-e2395117\resources\views/etudiant/edit.blade.php ENDPATH**/ ?>